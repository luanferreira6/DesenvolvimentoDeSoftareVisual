namespace MinhaFaculdade.Models
{
    public class Curso
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public string Area { get; set; }
        public int Duracao { get; set; }

        public Curso(int id, string nome, string area, int duracao)
        {
            Id = id;
            Nome = nome;
            Area = area;
            Duracao = duracao;
        }
    }
}