using Microsoft.AspNetCore.Mvc;

namespace MinhaFaculdade.Controllers
{
    public class ProfessoresController : Controller
    {
        public IActionResult Index(string nome)
        {
            ViewBag.FiltroNome = nome;
            return View();
        }

        public IActionResult Detalhes(int id)
        {
            ViewBag.IdProfessor = id;
            return View();
        }
    }
}