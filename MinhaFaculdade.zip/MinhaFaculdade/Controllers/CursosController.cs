using Microsoft.AspNetCore.Mvc;

namespace MinhaFaculdade.Controllers
{
    public class CursosController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Detalhes(int id)
        {
            ViewBag.IdRecebido = id;
            return View();
        }
    }
}